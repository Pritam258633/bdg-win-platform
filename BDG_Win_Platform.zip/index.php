<!-- index.php for BDG Win Game Platform -->
<?php echo 'Welcome to BDG Win!'; ?>